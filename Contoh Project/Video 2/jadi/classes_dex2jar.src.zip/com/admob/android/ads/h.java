package com.admob.android.ads;

public abstract interface h
{
  public abstract void a(r paramr);
  
  public abstract void a(r paramr, Exception paramException);
}


/* Location:           C:\Users\IrfanRZ\Desktop\Video 2\classes_dex2jar.jar
 * Qualified Name:     com.admob.android.ads.h
 * JD-Core Version:    0.7.0.1
 */