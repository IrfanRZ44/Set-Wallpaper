package com.admob.android.ads;

import org.json.JSONObject;

abstract interface s
{
  public abstract String h();
  
  public abstract JSONObject i();
}


/* Location:           C:\Users\IrfanRZ\Desktop\Video 2\classes_dex2jar.jar
 * Qualified Name:     com.admob.android.ads.s
 * JD-Core Version:    0.7.0.1
 */