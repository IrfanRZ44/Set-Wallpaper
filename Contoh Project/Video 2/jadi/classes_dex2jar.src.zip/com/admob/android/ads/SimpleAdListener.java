package com.admob.android.ads;

public class SimpleAdListener
  implements AdListener
{
  public void onFailedToReceiveAd(AdView paramAdView) {}
  
  public void onFailedToReceiveRefreshedAd(AdView paramAdView) {}
  
  public void onReceiveAd(AdView paramAdView) {}
  
  public void onReceiveRefreshedAd(AdView paramAdView) {}
}


/* Location:           C:\Users\IrfanRZ\Desktop\Video 2\classes_dex2jar.jar
 * Qualified Name:     com.admob.android.ads.SimpleAdListener
 * JD-Core Version:    0.7.0.1
 */