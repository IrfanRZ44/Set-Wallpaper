package com.ccpcreations.android.VLW;

public final class R
{
  public static final class array
  {
    public static final int laggingmodes = 2131099652;
    public static final int laggingmodes_values = 2131099653;
    public static final int playingmodes = 2131099648;
    public static final int playingmodes_values = 2131099649;
    public static final int zoomingmodes = 2131099650;
    public static final int zoomingmodes_values = 2131099651;
  }
  
  public static final class attr
  {
    public static final int backgroundColor = 2130771968;
    public static final int keywords = 2130771971;
    public static final int primaryTextColor = 2130771969;
    public static final int refreshInterval = 2130771972;
    public static final int secondaryTextColor = 2130771970;
  }
  
  public static final class drawable
  {
    public static final int filepickeritem = 2130837504;
    public static final int icon = 2130837505;
  }
  
  public static final class id
  {
    public static final int ButtonGetData = 2131230722;
    public static final int ButtonInit = 2131230720;
    public static final int ButtonNextFrame = 2131230723;
    public static final int ButtonOpen = 2131230721;
    public static final int DrawingView01 = 2131230724;
    public static final int ad = 2131230725;
  }
  
  public static final class layout
  {
    public static final int main = 2130903040;
  }
  
  public static final class raw
  {
    public static final int helpindex_en = 2131034112;
  }
  
  public static final class string
  {
    public static final int about_pref = 2131165233;
    public static final int about_prefdesc = 2131165234;
    public static final int app_name = 2131165187;
    public static final int changelog_pref = 2131165231;
    public static final int changelog_prefdesc = 2131165232;
    public static final int close = 2131165186;
    public static final int debug_mode_pref = 2131165218;
    public static final int debug_mode_prefdesc = 2131165219;
    public static final int do_not_skip_pref = 2131165212;
    public static final int do_not_skip_prefdesc = 2131165213;
    public static final int donate_pref = 2131165190;
    public static final int donate_prefdesc = 2131165191;
    public static final int donate_prefdialog = 2131165192;
    public static final int eula_agree_choice = 2131165227;
    public static final int eula_disagree_choice = 2131165228;
    public static final int eula_pref = 2131165226;
    public static final int help_about_prefcat = 2131165225;
    public static final int help_pref = 2131165229;
    public static final int help_prefdesc = 2131165230;
    public static final int no = 2131165185;
    public static final int pick_a_file_no_prefdesc = 2131165196;
    public static final int pick_a_file_pref = 2131165195;
    public static final int pick_a_file_title = 2131165193;
    public static final int pick_a_file_warning_dialog = 2131165198;
    public static final int pick_a_file_warning_dialog_title = 2131165197;
    public static final int playing_mode_delayed_runnable_prefitem = 2131165206;
    public static final int playing_mode_pref = 2131165203;
    public static final int playing_mode_prefdesc = 2131165204;
    public static final int playing_mode_working_thread_prefitem = 2131165205;
    public static final int pref_title = 2131165194;
    public static final int prefs_prefcat = 2131165189;
    public static final int random_file_mode_pref = 2131165201;
    public static final int random_file_mode_prefdesc = 2131165202;
    public static final int recursive_dir_pref = 2131165199;
    public static final int recursive_dir_prefdesc = 2131165200;
    public static final int shift_video_pref = 2131165214;
    public static final int shift_video_prefdesc = 2131165215;
    public static final int swiping_lag_1_prefitem = 2131165220;
    public static final int swiping_lag_2_prefitem = 2131165221;
    public static final int swiping_lag_3_prefitem = 2131165222;
    public static final int swiping_lag_4_prefitem = 2131165223;
    public static final int swiping_lag_5_prefitem = 2131165224;
    public static final int swiping_lag_pref = 2131165216;
    public static final int swiping_lag_prefdesc = 2131165217;
    public static final int wallpaperdescription = 2131165188;
    public static final int yes = 2131165184;
    public static final int zooming_mode_classic_prefitem = 2131165209;
    public static final int zooming_mode_letterboxed_prefitem = 2131165210;
    public static final int zooming_mode_pref = 2131165207;
    public static final int zooming_mode_prefdesc = 2131165208;
    public static final int zooming_mode_stretched_prefitem = 2131165211;
  }
  
  public static final class styleable
  {
    public static final int[] com_admob_android_ads_AdView = { 2130771968, 2130771969, 2130771970, 2130771971, 2130771972 };
    public static final int com_admob_android_ads_AdView_backgroundColor = 0;
    public static final int com_admob_android_ads_AdView_keywords = 3;
    public static final int com_admob_android_ads_AdView_primaryTextColor = 1;
    public static final int com_admob_android_ads_AdView_refreshInterval = 4;
    public static final int com_admob_android_ads_AdView_secondaryTextColor = 2;
  }
  
  public static final class xml
  {
    public static final int preferences = 2130968576;
    public static final int vlw = 2130968577;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\Video 2\classes_dex2jar.jar
 * Qualified Name:     com.ccpcreations.android.VLW.R
 * JD-Core Version:    0.7.0.1
 */