package android.support.transition;

import android.view.ViewGroup;

public abstract class af
{
  public abstract long a(ViewGroup paramViewGroup, Transition paramTransition, ah paramah1, ah paramah2);
  
  public abstract void a(ah paramah);
  
  public abstract String[] a();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.af
 * JD-Core Version:    0.7.0.1
 */