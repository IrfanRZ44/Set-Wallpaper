package android.support.transition;

import android.view.View;

abstract interface am
  extends at
{
  public abstract void a(View paramView);
  
  public abstract void b(View paramView);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.am
 * JD-Core Version:    0.7.0.1
 */