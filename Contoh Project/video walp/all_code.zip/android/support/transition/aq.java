package android.support.transition;

import android.view.ViewGroup;

abstract interface aq
{
  public abstract am a(ViewGroup paramViewGroup);
  
  public abstract void a(ViewGroup paramViewGroup, boolean paramBoolean);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.aq
 * JD-Core Version:    0.7.0.1
 */