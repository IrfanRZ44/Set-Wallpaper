package android.support.transition;

import android.animation.PropertyValuesHolder;
import android.graphics.Path;
import android.graphics.PointF;
import android.util.Property;

abstract interface x
{
  public abstract PropertyValuesHolder a(Property<?, PointF> paramProperty, Path paramPath);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.x
 * JD-Core Version:    0.7.0.1
 */