package android.support.transition;

import android.animation.ObjectAnimator;
import android.graphics.Path;
import android.graphics.PointF;
import android.util.Property;

abstract interface s
{
  public abstract <T> ObjectAnimator a(T paramT, Property<T, PointF> paramProperty, Path paramPath);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.s
 * JD-Core Version:    0.7.0.1
 */