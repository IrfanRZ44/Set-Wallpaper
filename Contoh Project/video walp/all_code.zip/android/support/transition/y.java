package android.support.transition;

public final class y
{
  public static final class a
  {
    public static final int action_container = 2131230737;
    public static final int action_divider = 2131230739;
    public static final int action_image = 2131230741;
    public static final int action_text = 2131230755;
    public static final int actions = 2131230757;
    public static final int async = 2131230765;
    public static final int blocking = 2131230770;
    public static final int chronometer = 2131230784;
    public static final int forever = 2131230817;
    public static final int ghost_view = 2131230818;
    public static final int icon = 2131230821;
    public static final int icon_group = 2131230822;
    public static final int info = 2131230834;
    public static final int italic = 2131230835;
    public static final int line1 = 2131230841;
    public static final int line3 = 2131230842;
    public static final int normal = 2131230859;
    public static final int notification_background = 2131230860;
    public static final int notification_main_column = 2131230861;
    public static final int notification_main_column_container = 2131230862;
    public static final int parent_matrix = 2131230866;
    public static final int right_icon = 2131230879;
    public static final int right_side = 2131230880;
    public static final int save_image_matrix = 2131230882;
    public static final int save_non_transition_alpha = 2131230883;
    public static final int save_scale_type = 2131230884;
    public static final int tag_transition_group = 2131230923;
    public static final int text = 2131230924;
    public static final int text2 = 2131230925;
    public static final int time = 2131230932;
    public static final int title = 2131230933;
    public static final int transition_current_scene = 2131230939;
    public static final int transition_layout_save = 2131230940;
    public static final int transition_position = 2131230941;
    public static final int transition_scene_layoutid_cache = 2131230942;
    public static final int transition_transform = 2131230943;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.y
 * JD-Core Version:    0.7.0.1
 */