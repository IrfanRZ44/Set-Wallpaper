package android.support.transition;

import android.view.View;

class aw
  extends av
{
  public at a(View paramView)
  {
    return new as(paramView);
  }
  
  public be b(View paramView)
  {
    return new bd(paramView);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.aw
 * JD-Core Version:    0.7.0.1
 */