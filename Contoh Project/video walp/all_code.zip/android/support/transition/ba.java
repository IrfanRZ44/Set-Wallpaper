package android.support.transition;

import android.graphics.Matrix;
import android.view.View;

abstract interface ba
{
  public abstract at a(View paramView);
  
  public abstract void a(View paramView, float paramFloat);
  
  public abstract void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void a(View paramView, Matrix paramMatrix);
  
  public abstract be b(View paramView);
  
  public abstract void b(View paramView, Matrix paramMatrix);
  
  public abstract float c(View paramView);
  
  public abstract void c(View paramView, Matrix paramMatrix);
  
  public abstract void d(View paramView);
  
  public abstract void e(View paramView);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.ba
 * JD-Core Version:    0.7.0.1
 */