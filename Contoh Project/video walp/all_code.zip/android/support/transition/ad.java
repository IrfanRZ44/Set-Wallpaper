package android.support.transition;

public class ad
  implements Transition.c
{
  public void a(Transition paramTransition) {}
  
  public void b(Transition paramTransition) {}
  
  public void c(Transition paramTransition) {}
  
  public void d(Transition paramTransition) {}
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.ad
 * JD-Core Version:    0.7.0.1
 */