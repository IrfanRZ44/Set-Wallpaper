package android.support.transition;

import android.animation.Animator;
import android.graphics.Matrix;
import android.widget.ImageView;

abstract interface n
{
  public abstract void a(ImageView paramImageView);
  
  public abstract void a(ImageView paramImageView, Animator paramAnimator);
  
  public abstract void a(ImageView paramImageView, Matrix paramMatrix);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.n
 * JD-Core Version:    0.7.0.1
 */