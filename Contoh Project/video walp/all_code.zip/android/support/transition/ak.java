package android.support.transition;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

class ak
  extends ar
  implements am
{
  ak(Context paramContext, ViewGroup paramViewGroup, View paramView)
  {
    super(paramContext, paramViewGroup, paramView);
  }
  
  static ak a(ViewGroup paramViewGroup)
  {
    return (ak)ar.d(paramViewGroup);
  }
  
  public void a(View paramView)
  {
    this.a.a(paramView);
  }
  
  public void b(View paramView)
  {
    this.a.b(paramView);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.ak
 * JD-Core Version:    0.7.0.1
 */