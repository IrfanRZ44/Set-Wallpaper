package android.support.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

abstract interface d
{
  public abstract void a(Animator paramAnimator);
  
  public abstract void a(Animator paramAnimator, AnimatorListenerAdapter paramAnimatorListenerAdapter);
  
  public abstract void b(Animator paramAnimator);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.transition.d
 * JD-Core Version:    0.7.0.1
 */