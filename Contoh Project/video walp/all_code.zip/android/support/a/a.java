package android.support.a;

public final class a
{
  public static final class a
  {
    public static final int notification_action_color_filter = 2131034192;
    public static final int notification_icon_bg_color = 2131034193;
    public static final int ripple_material_light = 2131034207;
    public static final int secondary_text_default_material_light = 2131034210;
  }
  
  public static final class b
  {
    public static final int compat_button_inset_horizontal_material = 2131099728;
    public static final int compat_button_inset_vertical_material = 2131099729;
    public static final int compat_button_padding_horizontal_material = 2131099730;
    public static final int compat_button_padding_vertical_material = 2131099731;
    public static final int compat_control_corner_material = 2131099732;
    public static final int notification_action_icon_size = 2131099794;
    public static final int notification_action_text_size = 2131099795;
    public static final int notification_big_circle_margin = 2131099796;
    public static final int notification_content_margin_start = 2131099797;
    public static final int notification_large_icon_height = 2131099798;
    public static final int notification_large_icon_width = 2131099799;
    public static final int notification_main_column_padding_top = 2131099800;
    public static final int notification_media_narrow_margin = 2131099801;
    public static final int notification_right_icon_size = 2131099802;
    public static final int notification_right_side_padding_top = 2131099803;
    public static final int notification_small_icon_background_padding = 2131099804;
    public static final int notification_small_icon_size_as_large = 2131099805;
    public static final int notification_subtext_size = 2131099806;
    public static final int notification_top_pad = 2131099807;
    public static final int notification_top_pad_large_text = 2131099808;
  }
  
  public static final class c
  {
    public static final int notification_action_background = 2131165304;
    public static final int notification_bg = 2131165305;
    public static final int notification_bg_low = 2131165306;
    public static final int notification_bg_low_normal = 2131165307;
    public static final int notification_bg_low_pressed = 2131165308;
    public static final int notification_bg_normal = 2131165309;
    public static final int notification_bg_normal_pressed = 2131165310;
    public static final int notification_icon_background = 2131165311;
    public static final int notification_template_icon_bg = 2131165312;
    public static final int notification_template_icon_low_bg = 2131165313;
    public static final int notification_tile_bg = 2131165314;
    public static final int notify_panel_notification_icon_bg = 2131165315;
  }
  
  public static final class d
  {
    public static final int action_container = 2131230737;
    public static final int action_divider = 2131230739;
    public static final int action_image = 2131230741;
    public static final int action_text = 2131230755;
    public static final int actions = 2131230757;
    public static final int async = 2131230765;
    public static final int blocking = 2131230770;
    public static final int chronometer = 2131230784;
    public static final int forever = 2131230817;
    public static final int icon = 2131230821;
    public static final int icon_group = 2131230822;
    public static final int info = 2131230834;
    public static final int italic = 2131230835;
    public static final int line1 = 2131230841;
    public static final int line3 = 2131230842;
    public static final int normal = 2131230859;
    public static final int notification_background = 2131230860;
    public static final int notification_main_column = 2131230861;
    public static final int notification_main_column_container = 2131230862;
    public static final int right_icon = 2131230879;
    public static final int right_side = 2131230880;
    public static final int tag_transition_group = 2131230923;
    public static final int text = 2131230924;
    public static final int text2 = 2131230925;
    public static final int time = 2131230932;
    public static final int title = 2131230933;
  }
  
  public static final class e
  {
    public static final int status_bar_notification_info_maxnum = 2131296266;
  }
  
  public static final class f
  {
    public static final int notification_action = 2131361845;
    public static final int notification_action_tombstone = 2131361846;
    public static final int notification_template_custom_big = 2131361853;
    public static final int notification_template_icon_group = 2131361854;
    public static final int notification_template_part_chronometer = 2131361858;
    public static final int notification_template_part_time = 2131361859;
  }
  
  public static final class g
  {
    public static final int status_bar_notification_info_overflow = 2131558476;
  }
  
  public static final class h
  {
    public static final int[] FontFamily = { 2130903205, 2130903206, 2130903207, 2130903208, 2130903209, 2130903210 };
    public static final int[] FontFamilyFont = { 16844082, 16844083, 16844095, 2130903203, 2130903211, 2130903212 };
    public static final int FontFamilyFont_android_font = 0;
    public static final int FontFamilyFont_android_fontStyle = 2;
    public static final int FontFamilyFont_android_fontWeight = 1;
    public static final int FontFamilyFont_font = 3;
    public static final int FontFamilyFont_fontStyle = 4;
    public static final int FontFamilyFont_fontWeight = 5;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.a.a
 * JD-Core Version:    0.7.0.1
 */