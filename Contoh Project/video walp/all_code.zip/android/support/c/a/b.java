package android.support.c.a;

import android.graphics.drawable.Animatable;

public abstract interface b
  extends Animatable
{}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.c.a.b
 * JD-Core Version:    0.7.0.1
 */