package android.support.design.internal;

import android.content.Context;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.j;
import android.support.v7.view.menu.u;

public class d
  extends u
{
  public d(Context paramContext, b paramb, j paramj)
  {
    super(paramContext, paramb, paramj);
  }
  
  public void a(boolean paramBoolean)
  {
    super.a(paramBoolean);
    ((h)s()).a(paramBoolean);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.design.internal.d
 * JD-Core Version:    0.7.0.1
 */