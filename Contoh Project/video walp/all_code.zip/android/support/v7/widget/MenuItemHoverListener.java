package android.support.v7.widget;

import android.support.v7.view.menu.h;
import android.view.MenuItem;

public abstract interface MenuItemHoverListener
{
  public abstract void onItemHoverEnter(h paramh, MenuItem paramMenuItem);
  
  public abstract void onItemHoverExit(h paramh, MenuItem paramMenuItem);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v7.widget.MenuItemHoverListener
 * JD-Core Version:    0.7.0.1
 */