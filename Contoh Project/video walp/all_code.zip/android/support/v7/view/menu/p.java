package android.support.v7.view.menu;

public abstract interface p
{
  public abstract void initialize(h paramh);
  
  public static abstract interface a
  {
    public abstract void a(j paramj, int paramInt);
    
    public abstract boolean a();
    
    public abstract j getItemData();
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.p
 * JD-Core Version:    0.7.0.1
 */