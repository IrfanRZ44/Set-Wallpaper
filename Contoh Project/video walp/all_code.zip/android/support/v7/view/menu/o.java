package android.support.v7.view.menu;

import android.content.Context;
import android.os.Parcelable;

public abstract interface o
{
  public abstract void a(Context paramContext, h paramh);
  
  public abstract void a(Parcelable paramParcelable);
  
  public abstract void a(h paramh, boolean paramBoolean);
  
  public abstract void a(a parama);
  
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean a();
  
  public abstract boolean a(h paramh, j paramj);
  
  public abstract boolean a(u paramu);
  
  public abstract int b();
  
  public abstract boolean b(h paramh, j paramj);
  
  public abstract Parcelable c();
  
  public static abstract interface a
  {
    public abstract void a(h paramh, boolean paramBoolean);
    
    public abstract boolean a(h paramh);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.o
 * JD-Core Version:    0.7.0.1
 */