package android.support.v7.view.menu;

import android.widget.ListView;

public abstract interface s
{
  public abstract void dismiss();
  
  public abstract ListView getListView();
  
  public abstract boolean isShowing();
  
  public abstract void show();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.s
 * JD-Core Version:    0.7.0.1
 */