package android.support.v7.view.menu;

class d<T>
{
  final T b;
  
  d(T paramT)
  {
    if (paramT == null) {
      throw new IllegalArgumentException("Wrapped Object can not be null.");
    }
    this.b = paramT;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.d
 * JD-Core Version:    0.7.0.1
 */