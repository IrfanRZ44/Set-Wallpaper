package android.support.v7.app;

import android.support.v7.view.b.a;

public abstract interface b
{
  public abstract android.support.v7.view.b a(b.a parama);
  
  public abstract void a(android.support.v7.view.b paramb);
  
  public abstract void b(android.support.v7.view.b paramb);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v7.app.b
 * JD-Core Version:    0.7.0.1
 */