package android.support.b;

public final class a
{
  public static final class a
  {
    public static final int coordinatorLayoutStyle = 2130903162;
    public static final int font = 2130903203;
    public static final int fontProviderAuthority = 2130903205;
    public static final int fontProviderCerts = 2130903206;
    public static final int fontProviderFetchStrategy = 2130903207;
    public static final int fontProviderFetchTimeout = 2130903208;
    public static final int fontProviderPackage = 2130903209;
    public static final int fontProviderQuery = 2130903210;
    public static final int fontStyle = 2130903211;
    public static final int fontWeight = 2130903212;
    public static final int keylines = 2130903239;
    public static final int layout_anchor = 2130903242;
    public static final int layout_anchorGravity = 2130903243;
    public static final int layout_behavior = 2130903244;
    public static final int layout_dodgeInsetEdges = 2130903247;
    public static final int layout_insetEdge = 2130903248;
    public static final int layout_keyline = 2130903249;
    public static final int statusBarBackground = 2130903331;
  }
  
  public static final class b
  {
    public static final int TextAppearance_Compat_Notification = 2131624178;
    public static final int TextAppearance_Compat_Notification_Info = 2131624179;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131624181;
    public static final int TextAppearance_Compat_Notification_Time = 2131624184;
    public static final int TextAppearance_Compat_Notification_Title = 2131624186;
    public static final int Widget_Compat_NotificationActionContainer = 2131624306;
    public static final int Widget_Compat_NotificationActionText = 2131624307;
    public static final int Widget_Support_CoordinatorLayout = 2131624319;
  }
  
  public static final class c
  {
    public static final int[] CoordinatorLayout = { 2130903239, 2130903331 };
    public static final int[] CoordinatorLayout_Layout = { 16842931, 2130903242, 2130903243, 2130903244, 2130903247, 2130903248, 2130903249 };
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    public static final int CoordinatorLayout_keylines = 0;
    public static final int CoordinatorLayout_statusBarBackground = 1;
    public static final int[] FontFamily = { 2130903205, 2130903206, 2130903207, 2130903208, 2130903209, 2130903210 };
    public static final int[] FontFamilyFont = { 16844082, 16844083, 16844095, 2130903203, 2130903211, 2130903212 };
    public static final int FontFamilyFont_android_font = 0;
    public static final int FontFamilyFont_android_fontStyle = 2;
    public static final int FontFamilyFont_android_fontWeight = 1;
    public static final int FontFamilyFont_font = 3;
    public static final int FontFamilyFont_fontStyle = 4;
    public static final int FontFamilyFont_fontWeight = 5;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.b.a
 * JD-Core Version:    0.7.0.1
 */