package android.support.v4.media;

import android.media.MediaMetadata;
import android.os.Parcel;

class f
{
  public static void a(Object paramObject, Parcel paramParcel, int paramInt)
  {
    ((MediaMetadata)paramObject).writeToParcel(paramParcel, paramInt);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.f
 * JD-Core Version:    0.7.0.1
 */