package android.support.v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

class f
{
  public static Bundle a(Object paramObject)
  {
    return ((PlaybackState)paramObject).getExtras();
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.f
 * JD-Core Version:    0.7.0.1
 */