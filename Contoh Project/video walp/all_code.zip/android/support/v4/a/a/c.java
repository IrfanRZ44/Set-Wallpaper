package android.support.v4.a.a;

import android.graphics.drawable.Drawable;

public abstract interface c
{
  public abstract Drawable a();
  
  public abstract void a(Drawable paramDrawable);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.a.c
 * JD-Core Version:    0.7.0.1
 */