package android.support.v4.widget;

import android.support.v4.os.a;

public abstract interface b
{
  public static final boolean a = ;
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.b
 * JD-Core Version:    0.7.0.1
 */