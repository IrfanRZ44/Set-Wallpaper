package android.support.v4.e;

public abstract interface c
{
  public abstract boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.e.c
 * JD-Core Version:    0.7.0.1
 */