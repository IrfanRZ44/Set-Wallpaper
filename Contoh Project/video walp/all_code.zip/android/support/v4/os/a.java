package android.support.v4.os;

import android.os.Build.VERSION;

public class a
{
  @Deprecated
  public static boolean a()
  {
    return Build.VERSION.SDK_INT >= 27;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.os.a
 * JD-Core Version:    0.7.0.1
 */