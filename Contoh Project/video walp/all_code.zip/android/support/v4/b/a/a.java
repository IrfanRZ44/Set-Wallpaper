package android.support.v4.b.a;

import android.view.Menu;

public abstract interface a
  extends Menu
{}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.a.a
 * JD-Core Version:    0.7.0.1
 */