package android.support.v4.b.a;

import android.view.SubMenu;

public abstract interface c
  extends a, SubMenu
{}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.a.c
 * JD-Core Version:    0.7.0.1
 */