package android.support.v4.view;

public abstract interface i
{
  public abstract boolean isNestedScrollingEnabled();
  
  public abstract void stopNestedScroll();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.i
 * JD-Core Version:    0.7.0.1
 */