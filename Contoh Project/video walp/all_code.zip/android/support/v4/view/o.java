package android.support.v4.view;

import android.view.View;

public abstract interface o
{
  public abstract aa a(View paramView, aa paramaa);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.o
 * JD-Core Version:    0.7.0.1
 */