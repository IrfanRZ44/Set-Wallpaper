package android.support.v4.view;

import android.view.View;
import android.view.ViewGroup;

public class n
{
  private final ViewGroup a;
  private int b;
  
  public n(ViewGroup paramViewGroup)
  {
    this.a = paramViewGroup;
  }
  
  public int a()
  {
    return this.b;
  }
  
  public void a(View paramView)
  {
    a(paramView, 0);
  }
  
  public void a(View paramView, int paramInt)
  {
    this.b = 0;
  }
  
  public void a(View paramView1, View paramView2, int paramInt)
  {
    a(paramView1, paramView2, paramInt, 0);
  }
  
  public void a(View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    this.b = paramInt1;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.n
 * JD-Core Version:    0.7.0.1
 */