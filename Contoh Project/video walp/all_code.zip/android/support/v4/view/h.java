package android.support.v4.view;

import android.view.MotionEvent;

public final class h
{
  public static boolean a(MotionEvent paramMotionEvent, int paramInt)
  {
    return (paramInt & paramMotionEvent.getSource()) == paramInt;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.h
 * JD-Core Version:    0.7.0.1
 */