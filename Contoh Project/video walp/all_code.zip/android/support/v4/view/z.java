package android.support.v4.view;

import android.view.View;

public abstract interface z
{
  public abstract void a(View paramView);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.z
 * JD-Core Version:    0.7.0.1
 */