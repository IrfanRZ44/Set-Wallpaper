package android.support.v4.view;

import android.view.View;

public class y
  implements x
{
  public void onAnimationCancel(View paramView) {}
  
  public void onAnimationEnd(View paramView) {}
  
  public void onAnimationStart(View paramView) {}
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.y
 * JD-Core Version:    0.7.0.1
 */