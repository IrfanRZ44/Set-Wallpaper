package android.support.v4.view;

import android.view.View;

public abstract interface x
{
  public abstract void onAnimationCancel(View paramView);
  
  public abstract void onAnimationEnd(View paramView);
  
  public abstract void onAnimationStart(View paramView);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.x
 * JD-Core Version:    0.7.0.1
 */