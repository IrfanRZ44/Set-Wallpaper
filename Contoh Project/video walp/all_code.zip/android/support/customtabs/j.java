package android.support.customtabs;

public final class j
{
  public static final class a
  {
    public static final int browser_actions_context_menu_max_width = 2131099723;
    public static final int browser_actions_context_menu_min_padding = 2131099724;
    public static final int compat_button_inset_horizontal_material = 2131099728;
    public static final int compat_button_inset_vertical_material = 2131099729;
    public static final int compat_button_padding_horizontal_material = 2131099730;
    public static final int compat_button_padding_vertical_material = 2131099731;
    public static final int compat_control_corner_material = 2131099732;
    public static final int notification_action_icon_size = 2131099794;
    public static final int notification_action_text_size = 2131099795;
    public static final int notification_big_circle_margin = 2131099796;
    public static final int notification_content_margin_start = 2131099797;
    public static final int notification_large_icon_height = 2131099798;
    public static final int notification_large_icon_width = 2131099799;
    public static final int notification_main_column_padding_top = 2131099800;
    public static final int notification_media_narrow_margin = 2131099801;
    public static final int notification_right_icon_size = 2131099802;
    public static final int notification_right_side_padding_top = 2131099803;
    public static final int notification_small_icon_background_padding = 2131099804;
    public static final int notification_small_icon_size_as_large = 2131099805;
    public static final int notification_subtext_size = 2131099806;
    public static final int notification_top_pad = 2131099807;
    public static final int notification_top_pad_large_text = 2131099808;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.customtabs.j
 * JD-Core Version:    0.7.0.1
 */