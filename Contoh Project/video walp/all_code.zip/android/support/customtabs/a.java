package android.support.customtabs;

import android.net.Uri;
import android.os.Bundle;

public class a
{
  public void a(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle) {}
  
  public void a(int paramInt, Bundle paramBundle) {}
  
  public void a(Bundle paramBundle) {}
  
  public void a(String paramString, Bundle paramBundle) {}
  
  public void b(String paramString, Bundle paramBundle) {}
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.support.customtabs.a
 * JD-Core Version:    0.7.0.1
 */