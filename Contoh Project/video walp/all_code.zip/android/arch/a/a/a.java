

java.util.concurrent.Executor

a
  

  a
  d = ()
  
    execute
    
      a()b
    
  
  e = ()
  
    execute
    
      a()a
    
  
  b = c;
  private c c = new b();
  
  public static a a()
  {
    if (a != null) {
      return a;
    }
    try
    {
      if (a == null) {
        a = new a();
      }
      return a;
    }
    finally {}
  }
  
  public void a(Runnable paramRunnable)
  {
    this.b.a(paramRunnable);
  }
  
  public void b(Runnable paramRunnable)
  {
    this.b.b(paramRunnable);
  }
  
  public boolean b()
  {
    return this.b.b();
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.a.a.a
 * JD-Core Version:    0.7.0.1
 */