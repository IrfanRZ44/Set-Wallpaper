package android.arch.lifecycle;

public class SingleGeneratedAdapterObserver
  implements GenericLifecycleObserver
{
  private final c a;
  
  SingleGeneratedAdapterObserver(c paramc)
  {
    this.a = paramc;
  }
  
  public void a(h paramh, e.a parama)
  {
    this.a.a(paramh, parama, false, null);
    this.a.a(paramh, parama, true, null);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.SingleGeneratedAdapterObserver
 * JD-Core Version:    0.7.0.1
 */