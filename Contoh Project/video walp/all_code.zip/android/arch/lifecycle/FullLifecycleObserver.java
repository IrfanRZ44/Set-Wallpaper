package android.arch.lifecycle;

abstract interface FullLifecycleObserver
  extends g
{
  public abstract void a(h paramh);
  
  public abstract void b(h paramh);
  
  public abstract void c(h paramh);
  
  public abstract void d(h paramh);
  
  public abstract void e(h paramh);
  
  public abstract void f(h paramh);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.FullLifecycleObserver
 * JD-Core Version:    0.7.0.1
 */