package android.arch.lifecycle;

public abstract class s
{
  protected void onCleared() {}
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.s
 * JD-Core Version:    0.7.0.1
 */