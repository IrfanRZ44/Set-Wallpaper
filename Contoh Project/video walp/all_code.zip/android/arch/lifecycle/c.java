package android.arch.lifecycle;

public abstract interface c
{
  public abstract void a(h paramh, e.a parama, boolean paramBoolean, l paraml);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.c
 * JD-Core Version:    0.7.0.1
 */