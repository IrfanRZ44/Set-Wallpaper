package android.arch.lifecycle;

public class m<T>
  extends LiveData<T>
{
  public void postValue(T paramT)
  {
    super.postValue(paramT);
  }
  
  public void setValue(T paramT)
  {
    super.setValue(paramT);
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.m
 * JD-Core Version:    0.7.0.1
 */