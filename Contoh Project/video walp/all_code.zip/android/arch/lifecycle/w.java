package android.arch.lifecycle;

public abstract interface w
{
  public abstract v getViewModelStore();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.w
 * JD-Core Version:    0.7.0.1
 */