package android.arch.lifecycle;

public abstract interface n<T>
{
  public abstract void onChanged(T paramT);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.n
 * JD-Core Version:    0.7.0.1
 */