package android.arch.lifecycle;

@Deprecated
public abstract interface j
  extends h
{
  public abstract i a();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.j
 * JD-Core Version:    0.7.0.1
 */