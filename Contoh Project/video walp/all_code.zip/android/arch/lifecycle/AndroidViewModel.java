package android.arch.lifecycle;

import android.annotation.SuppressLint;
import android.app.Application;

public class AndroidViewModel
  extends s
{
  @SuppressLint({"StaticFieldLeak"})
  private Application a;
  
  public AndroidViewModel(Application paramApplication)
  {
    this.a = paramApplication;
  }
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.AndroidViewModel
 * JD-Core Version:    0.7.0.1
 */