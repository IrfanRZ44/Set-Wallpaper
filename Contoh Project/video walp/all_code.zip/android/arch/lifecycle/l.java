package android.arch.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class l
{
  private Map<String, Integer> a = new HashMap();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.l
 * JD-Core Version:    0.7.0.1
 */