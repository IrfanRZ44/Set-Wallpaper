package android.arch.lifecycle;

public abstract interface h
{
  public abstract e getLifecycle();
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.h
 * JD-Core Version:    0.7.0.1
 */