package android.arch.lifecycle;

public abstract interface GenericLifecycleObserver
  extends g
{
  public abstract void a(h paramh, e.a parama);
}


/* Location:           C:\Users\IrfanRZ\Desktop\video walp\classes_dex2jar.jar
 * Qualified Name:     android.arch.lifecycle.GenericLifecycleObserver
 * JD-Core Version:    0.7.0.1
 */